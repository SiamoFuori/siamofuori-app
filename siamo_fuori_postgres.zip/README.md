# Siamo Fuori App - Deploy con PostgreSQL en Render

## 1) Crea servicio PostgreSQL en Render
1. En Render Dashboard, selecciona **New** → **PostgreSQL**.
2. Elige el plan gratuito y haz clic en **Create Database**.
3. Copia la **Connection URL** (DATABASE_URL) que aparece.

## 2) Prepara el repositorio
Asegúrate de tener en la raíz:
- `app.py`
- `requirements.txt`
- `Procfile`
- Carpeta `templates/` con los archivos HTML.
- Carpeta `static/` con manifest y service-worker.

Sube todo esto a GitHub.

## 3) Configura tu Web Service en Render
1. En Render Dashboard, selecciona **New** → **Web Service**.
2. Conecta tu repositorio de GitHub.
3. En **Environment**, agrega variable:
   - **Key:** `DATABASE_URL`
   - **Value:** pega tu URL de PostgreSQL.
4. En **Build Command** usa:
   ```
   pip install -r requirements.txt
   ```
5. En **Start Command** usa:
   ```
   gunicorn app:app
   ```
6. Haz clic en **Create Web Service**.

## 4) Resultado
Render desplegará tu app y te dará una URL pública HTTPS.  
Visítala en tu navegador de móvil y usa **Agregar a pantalla de inicio** para instalar tu PWA.

---

¡Listo! Tu app estará usando PostgreSQL de forma persistente y no se perderán los datos.
